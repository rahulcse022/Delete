export const USDTTokenAddress = "0x15551b0D3989D2A8b7306038EaCFea74611BEAD7";
export const MTCTokenAddress = "0x2786C0f1409F69a41418bA626da25d460Fe60b21";
export const ICOContractAddress = "0xDdCe97dF73Ca6B40759F1D9fcf3ed8482C3906C5";
export const TokenContractAddress =
  "0xe01a401FC43b594577912d1A684030d93c0D2BfF";

